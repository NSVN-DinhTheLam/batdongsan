<!DOCTYPE html>
<!--[if IE 8]> <html <?php language_attributes(); ?> class="ie8"> <![endif]-->
<!--[if !IE]> <html <?php language_attributes(); ?>> <![endif]-->

<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>" />
    <link rel="profile" href="http://gmgp.org/xfn/11" />
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
 
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>AnPhatHung Land</title>

    <!-- CSS -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600&amp;subset=vietnamese" rel="stylesheet">
    <link href="<?php echo THEME_URI; ?>/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo THEME_URI; ?>/vendor/jasny-bootstrap/css/jasny-bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo THEME_URI; ?>/vendor/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="<?php echo THEME_URI; ?>/vendor/owlcarousel/assets/owl.theme.default.min.css" rel="stylesheet">
    <link href="<?php echo THEME_URI; ?>/css/fontawesome-all.min.css" rel="stylesheet">
    <link href="<?php echo THEME_URI; ?>/css/animate.css" rel="stylesheet">
    <link href="<?php echo THEME_URI; ?>/css/site.css" rel="stylesheet">

    <!-- Scripts -->
    <script src="<?php echo THEME_URI; ?>/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo THEME_URI; ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo THEME_URI; ?>/vendor/jasny-bootstrap/js/jasny-bootstrap.min.js"></script>
    <script src="<?php echo THEME_URI; ?>/vendor/owlcarousel/owl.carousel.min.js"></script>
    <script src="<?php echo THEME_URI; ?>/vendor/wow/wow.min.js"></script>
    <script src="<?php echo THEME_URI; ?>/js/site.js"></script>

    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <!-- Navigation -->
    <nav class="navbar-main navbar fixed-top navbar-expand-lg navbar-light bg-white fixed-top">
        <div class="container">
            <button id="silde-toggler" class="navbar-toggler navbar-toggler-right" type="button" data-toggle="slide-collapse" data-target="#navbar-top"
                aria-controls="navbar-top" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <a class="navbar-brand" href="index.html">
                <img class="logo" src="<?php echo THEME_URI; ?>/images/logo.jpg">
            </a>
            <div id="navbar-top" class="collapse navbar-collapse offcanvas-collapse">
                <ul class="navbar-nav ml-auto">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="about.html">Giới thiệu</a>
                    <div class="dropdown-menu dropdown-menu-left">
                    <a class="dropdown-item" href="about.html">Giới thiệu An Phát Hưng</a>
                    <a class="dropdown-item" href="about.html">Tầm nhìn- Sứ mệnh- Giá trị cốt lõi</a>
                    <a class="dropdown-item" href="about.html">Sản phẩm dịch vụ</a>
                    <a class="dropdown-item" href="about.html">Văn hóa doanh nghiệp</a>
                    <a class="dropdown-item" href="about.html">Năng lực cạnh tranh</a>
                    </div>  
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="news-home.html" id="navbarDropdownBlog">Tin tức</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="portfolio-home.html">Dự án nghỉ dưỡng</a>
                    <div class="dropdown-menu dropdown-menu-left">
                    <a class="dropdown-item" href="portfolio-item.html">Dự án nghỉ dưỡng 1</a>
                    <a class="dropdown-item" href="portfolio-item.html">Dự án nghỉ dưỡng 2</a>
                    <a class="dropdown-item" href="portfolio-item.html">Dự án nghỉ dưỡng 3</a>
                    <a class="dropdown-item" href="portfolio-item.html">Dự án nghỉ dưỡng 4</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="portfolio-home.html">Dự án nhà ở</a>
                    <div class="dropdown-menu dropdown-menu-left">
                    <a class="dropdown-item" href="portfolio-item.html">Dự án nhà ở 1</a>
                    <a class="dropdown-item" href="portfolio-item.html">Dự án nhà ở 2</a>
                    <a class="dropdown-item" href="portfolio-item.html">Dự án nhà ở 3</a>
                    <a class="dropdown-item" href="portfolio-item.html">Dự án nhà ở 4</a>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="library.html">Thư viện</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="recruit.html">Tuyển dụng</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact.html">Liên hệ</a>
                </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="menu-overlay"></div>