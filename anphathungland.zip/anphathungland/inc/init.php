<?php
require_once( 'logo.php' );
require_once( 'menu.php' );
// Register Custom Navigation Walker
require_once( 'class-wp-bootstrap-navwalker.php' );