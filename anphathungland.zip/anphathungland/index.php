<?php
get_header(); ?>

<div id="banner" class="banner-box owl-carousel owl-theme">
  <div class="banner-item">
    <div class="absolute-box about-box">
    </div>
    <div class="image" style="background-image: url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner/banner-1.jpg)"></div>
  </div>
  <div class="banner-item">
    <div class="absolute-box about-box">
    </div>
    <div class="image" style="background-image: url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner/banner-2.png)"></div>
  </div>
</div>

<div class="container">
  <div class="home-feature">
    <h1 class="module-title my-5 color-theme text-center">CÁC DỰ ÁN NỔI BẬT</h1>
    <div class="home-feature-box row owl-carousel owl-theme">
      <div class="box-item">
        <a class="image-box" href="#">
          <img class="placeholder" src="<?php echo get_stylesheet_directory_uri(); ?>/images/hero/placeholder-hero.png" />
          <div class="image">
            <img alt="" src="<?php echo get_stylesheet_directory_uri(); ?>/images/hero/hero-1.jpg" />
          </div>
        </a>
        <div class="text">
          <a class="title" href="#">BẢN XÔI VILLAGE BA VÌ</a>
          <div class="content">
            <span class="input-group extra-info position">Đường Đào Trí, Phường Phú Thuận, Quận 7, Hồ Chí Minh</span>
            <div class="input-group">
              <span class="extra-info size" data-toggle="tooltip" data-placement="top" title="Diện tích">25m<sup>2</sup></span>
              <span class="extra-info price" data-toggle="tooltip" data-placement="top" title="Giá tiền">26 triệu/m<sup>2</sup></span>
            </div>
            <div class="input-group">
              <span class="extra-info bed highlight" data-toggle="tooltip" data-placement="top" title="Phòng ngủ">2</span>
              <span class="extra-info bathroom highlight" data-toggle="tooltip" data-placement="top" title="Phòng tắm">2</span>
              <span class="extra-info dining highlight" data-toggle="tooltip" data-placement="top" title="Phòng ăn">1</span>
            </div>
          </div>
        </div>
      </div>
      <div class="box-item">
        <a class="image-box" href="#">
          <img class="placeholder" src="<?php echo get_stylesheet_directory_uri(); ?>/images/hero/placeholder-hero.png" />
          <div class="image">
            <img alt="" src="<?php echo get_stylesheet_directory_uri(); ?>/images/hero/hero-1.jpg" />
          </div>
        </a>
        <div class="text">
          <a class="title" href="#">BẢN XÔI VILLAGE BA VÌ</a>
          <div class="content">
            <span class="input-group extra-info position">Đường Đào Trí, Phường Phú Thuận, Quận 7, Hồ Chí Minh</span>
            <div class="input-group">
              <span class="extra-info size" data-toggle="tooltip" data-placement="top" title="Diện tích">25m<sup>2</sup></span>
              <span class="extra-info price" data-toggle="tooltip" data-placement="top" title="Giá tiền">26 triệu/m<sup>2</sup></span>
            </div>
            <div class="input-group">
              <span class="extra-info bed highlight" data-toggle="tooltip" data-placement="top" title="Phòng ngủ">2</span>
              <span class="extra-info bathroom highlight" data-toggle="tooltip" data-placement="top" title="Phòng tắm">2</span>
            </div>
          </div>
        </div>
      </div>
      <div class="box-item">
        <a class="image-box" href="#">
          <img class="placeholder" src="<?php echo get_stylesheet_directory_uri(); ?>/images/hero/placeholder-hero.png" />
          <div class="image">
            <img alt="" src="<?php echo get_stylesheet_directory_uri(); ?>/images/hero/hero-1.jpg" />
          </div>
        </a>
        <div class="text">
          <a class="title" href="#">BẢN XÔI VILLAGE BA VÌ</a>
          <div class="content">
            <span class="input-group extra-info position">Đường Đào Trí, Phường Phú Thuận, Quận 7, Hồ Chí Minh</span>
            <div class="input-group">
              <span class="extra-info size" data-toggle="tooltip" data-placement="top" title="Diện tích">25m<sup>2</sup></span>
              <span class="extra-info price" data-toggle="tooltip" data-placement="top" title="Giá tiền">26 triệu/m<sup>2</sup></span>
            </div>
            <div class="input-group">
              <span class="extra-info bed highlight" data-toggle="tooltip" data-placement="top" title="Phòng ngủ">2</span>
              <span class="extra-info bathroom highlight" data-toggle="tooltip" data-placement="top" title="Phòng tắm">2</span>
            </div>
          </div>
        </div>
      </div>
      <div class="box-item">
        <a class="image-box" href="#">
          <img class="placeholder" src="<?php echo get_stylesheet_directory_uri(); ?>/images/hero/placeholder-hero.png" />
          <div class="image">
            <img alt="" src="<?php echo get_stylesheet_directory_uri(); ?>/images/hero/hero-1.jpg" />
          </div>
        </a>
        <div class="text">
          <a class="title" href="#">BẢN XÔI VILLAGE BA VÌ</a>
          <div class="content">
            <span class="input-group extra-info position">Đường Đào Trí, Phường Phú Thuận, Quận 7, Hồ Chí Minh</span>
            <div class="input-group">
              <span class="extra-info size" data-toggle="tooltip" data-placement="top" title="Diện tích">25m<sup>2</sup></span>
              <span class="extra-info price" data-toggle="tooltip" data-placement="top" title="Giá tiền">26 triệu/m<sup>2</sup></span>
            </div>
            <div class="input-group">
              <span class="extra-info bed highlight" data-toggle="tooltip" data-placement="top" title="Phòng ngủ">2</span>
              <span class="extra-info bathroom highlight" data-toggle="tooltip" data-placement="top" title="Phòng tắm">2</span>
            </div>
          </div>
        </div>
      </div>
      <div class="box-item">
        <a class="image-box" href="#">
          <img class="placeholder" src="<?php echo get_stylesheet_directory_uri(); ?>/images/hero/placeholder-hero.png" />
          <div class="image">
            <img alt="" src="<?php echo get_stylesheet_directory_uri(); ?>/images/hero/hero-1.jpg" />
          </div>
        </a>
        <div class="text">
          <a class="title" href="#">BẢN XÔI VILLAGE BA VÌ</a>
          <div class="content">
            <span class="input-group extra-info position">Đường Đào Trí, Phường Phú Thuận, Quận 7, Hồ Chí Minh</span>
            <div class="input-group">
              <span class="extra-info size" data-toggle="tooltip" data-placement="top" title="Diện tích">25m<sup>2</sup></span>
              <span class="extra-info price" data-toggle="tooltip" data-placement="top" title="Giá tiền">26 triệu/m<sup>2</sup></span>
            </div>
            <div class="input-group">
              <span class="extra-info bed highlight" data-toggle="tooltip" data-placement="top" title="Phòng ngủ">2</span>
              <span class="extra-info bathroom highlight" data-toggle="tooltip" data-placement="top" title="Phòng tắm">2</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <hr/>

  <div class="home-testimonial">
    <h1 class="module-title my-5 color-theme text-center">Đánh giá của khách hàng</h1>
    <div class="row home-testimonial-box owl-carousel owl-theme">
      <div class="media">
        <img class="mr-3" src="<?php echo get_stylesheet_directory_uri(); ?>/images/avatar/noavatar-64.jpg" alt="Generic placeholder image">
        <div class="media-body">
          <h5 class="media-title mt-0">Bùi Tiến Dũng</h5>
          <h6 class="media-subtitle color-theme">Đã mua nhà tại Ba Vì <i class="fa fa-check-circle"></i></h6>
          <div class="text-muted">Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in
            vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla.
          </div>
        </div>
      </div>
      <div class="media">
        <img class="mr-3" src="<?php echo get_stylesheet_directory_uri(); ?>/images/avatar/noavatar-64.jpg" alt="Generic placeholder image">
        <div class="media-body">
          <h5 class="media-title mt-0">Tim Cater</h5>
          <h6 class="media-subtitle color-theme">Đã mua nhà tại Ba Vì <i class="fa fa-check-circle"></i></h6>
          <div class="text-muted">Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in
            vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla.
          </div>
        </div>
      </div>
      <div class="media">
        <img class="mr-3" src="<?php echo get_stylesheet_directory_uri(); ?>/images/avatar/noavatar-64.jpg" alt="Generic placeholder image">
        <div class="media-body">
          <h5 class="media-title mt-0">Tim Cater</h5>
          <h6 class="media-subtitle color-theme">Đã mua nhà tại Ba Vì <i class="fa fa-check-circle"></i></h6>
          <div class="text-muted">Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in
            vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla.
          </div>
        </div>
      </div>
      <div class="media">
        <img class="mr-3" src="<?php echo get_stylesheet_directory_uri(); ?>/images/avatar/noavatar-64.jpg" alt="Generic placeholder image">
        <div class="media-body">
          <h5 class="media-title mt-0">Tim Cater</h5>
          <h6 class="media-subtitle color-theme">Đã mua nhà tại Ba Vì <i class="fa fa-check-circle"></i></h6>
          <div class="text-muted">Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in
            vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla.
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="home-news bg-f0">
  <div class="container">
    <h1 class="module-title my-5 color-theme text-center">Tin tức</h1>
    <div class="row">
      <div class="col-md-7 col-xs-12">
        <div class="item-box overlay wow fadeInUp">
          <a href="#"><div class="image"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/news/news-1.jpg" /></div></a>
          <div class="text d-flex flex-column">
            <a href="#"><h4 class="title">Vingroup sẽ “thâu tóm” toàn bộ thị trường biệt thự, nhà liền kề tại Hà Nội đến năm 2019</h4></a>
            <div class="description mb-auto">Mới đây, Savills cho biết từ quý II/2018 đến hết năm 2019 Vingroup sẽ cho ra mắt khoảng hơn 11.500 căn biệt
              thự, nhà liền kề, phần lớn tập trung tại Đông Anh, Gia Lâm, Đan Phượng và Từ Liêm.</div>
            <div class="meta d-flex flex-row">
              Nov 12
              <a href="#" class="link">
                <i class="fa fa-arrow-right"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-5 col-xs-12">
        <div class="card flex-md-row mb-4 box-shadow h-md-250 wow fadeInUp">
          <a class="flex-auto d-none d-lg-block card-img-left" href="#"><img alt="Thumbnail [200x250]" src="<?php echo get_stylesheet_directory_uri(); ?>/images/news/news-1.jpg" data-holder-rendered="true"></a>
          <div class="card-body d-flex flex-column">
            <a class="card-text mb-auto" href="#">T&T Twin Towers là tòa tháp đáng sống nhất tại Đà Nẵng</a>
            <div class="d-flex flex-row">
              <div class="text-muted">Nov 12</div>
              <a href="#" class="link"><i class="fa fa-arrow-right"></i></a>
            </div>
          </div>
        </div>
        <div class="card flex-md-row mb-4 box-shadow h-md-250 wow fadeInUp">
            <a class="flex-auto d-none d-lg-block card-img-left" href="#"><img alt="Thumbnail [200x250]" src="<?php echo get_stylesheet_directory_uri(); ?>/images/news/news-2.jpg" data-holder-rendered="true"></a>
            <div class="card-body d-flex flex-column">
            <a class="card-text mb-auto" href="#">T&T Twin Towers là tòa tháp đáng sống nhất tại Đà Nẵng</a>
            <div class="d-flex flex-row">
              <div class="text-muted">Nov 12</div>
              <a href="#" class="link"><i class="fa fa-arrow-right"></i></a>
            </div>
          </div>
        </div>
        <div class="card flex-md-row mb-4 box-shadow h-md-250 wow fadeInUp">
            <a class="flex-auto d-none d-lg-block card-img-left" href="#"><img alt="Thumbnail [200x250]" src="<?php echo get_stylesheet_directory_uri(); ?>/images/news/news-3.jpg" data-holder-rendered="true"></a>
            <div class="card-body d-flex flex-column">
            <a class="card-text mb-auto" href="#">T&T Twin Towers là tòa tháp đáng sống nhất tại Đà Nẵng</a>
            <div class="d-flex flex-row">
              <div class="text-muted">Nov 12</div>
              <a href="#" class="link"><i class="fa fa-arrow-right"></i></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="call-to-action">
  <div class="container">
    <div class="row">
      <div class="col-md-7 col-lg-8 wow fadeInUp">
        <h3 class="color-theme">Chúng tôi sẵn sàng tư vấn 24/7</h3>
        <p class="text-dark">Với đội ngũ nhân viên hơn 6 năm kinh nghiệm, không chỉ là hướng dẫn và xử lý các vấn đề về nhà đất, chúng tôi luôn đồng hành tư vấn và phát triển cùng gia đình bạn.</p>
      </div>
      <div class="col-md-5 col-lg-4 text-center">
        <a class="call btn btn-lg btn-success wow fadeInUp" href="tel:0906227669"><span><i class="fa fa-phone-volume fa-fw"></i>Liên hệ ngay</span></a>
      </div>
    </div>
  </div>
</div>

<div class="footer-wrapper">
  <div class="footer-top">
    <div class="container">
      <div class="row">
        <ul class="col-sm-12 d-flex justify-content-end">
          <li><a href="#">Trang chủ</a></li>
          <li><a href="#">Giới thiệu</a></li>
          <li><a href="#">Dự án Nghỉ dưỡng</a></li>
          <li><a href="#">Dự án Nhà ở</a></li>
          <li><a href="#">Thư viện</a></li>
          <li><a href="#">Tin tức</a></li>
          <li><a href="#">Tuyển dụng</a></li>
          <li><a href="#">Liên hệ</a></li>
        </ul>
      </div>
    </div>
  </div>
  <div class="footer-main">
    <div class="container">
      <div class="row">
        <div class="col-md-2 text-center">
          <a href="/"><img class="logo" src="<?php echo get_stylesheet_directory_uri(); ?>/images/logo.jpg" /></a>
        </div>
        <div class="col-md-5">
          <h5 class="color-theme bold my-sm-3 my-md-2 text-center text-md-left">An Phát Hưng Land</h5>
          <div class="contact-info">
            <ul class="fa-ul">
              <li><span class="fa-li"><i class="fa fa-map-marker-alt fa-fw"></i></span> <span class="bold">Địa chỉ:</span> P10.03 Tòa nhà Kim Ánh, 78 Duy Tân, Cầu Giấy, Hà Nội</li>
              <li><span class="fa-li"><i class="fa fa-phone-volume fa-fw"></i></span> <span class="bold">Hotline:</span> <a href="tel:0436321668">0436.321.668</a> - <a href="tel:0906227669">0906.227.669</a></li>
              <li><span class="fa-li"><i class="fa fa-envelope fa-fw"></i></span> <span class="bold">Email:</span> <a href="mailto:contact@anphathungland.com">contact@anphathungland.com</a></li>
            </ul>
          </div>
        </div>
        <div class="col-md-5">
          
        </div>
      </div>
    </div>
  </div>
</div>

</body>

</html>

<?php
//get_sidebar();
get_footer();